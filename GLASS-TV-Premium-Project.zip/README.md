# GLASS TV Premium Starter

Native Java/XML Android TV launcher project for Android 5.1.1+ (minSdk 22), package `com.iptv.glass`.

## Build
- Requires JDK 17 and Android SDK Platform 35.
- Open the folder in Android Studio and sync Gradle, or push the entire folder to GitHub.
- GitHub Actions builds a debug APK at `.github/workflows/main.yml`.
- In Actions, open the successful run and download `GLASS-TV-Premium-APK` under Artifacts.

## Implemented
- Dark cinematic home screen with glass-style panels and focus states.
- Detects installed launchable apps, shows icons/names and launches them.
- Favorites and recently opened apps stored locally.
- Toggle home sections in Settings.
- Select and persist an image wallpaper.
- Anime and Movies navigation screens.
- Android TV launcher intent filters and landscape orientation.

## Not yet implemented
The Anime screen is a navigation/catalog shell, not a streaming catalog or player. No streaming sources are included. Advanced artwork/banner feeds, true category management, full animation system and end-to-end testing on the target Daiwa TV remain future work. Wallpaper persistence and app discovery should be verified on the actual firmware.

## Notes
This project does not include IPTV, M3U, live-TV playback, or unauthorized streaming.
