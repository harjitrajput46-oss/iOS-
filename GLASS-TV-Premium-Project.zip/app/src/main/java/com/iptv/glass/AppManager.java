package com.iptv.glass;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.*;

public class AppManager {
    private final Context c;
    public AppManager(Context c){this.c=c;}
    public List<ApplicationInfo> all() {
        PackageManager pm=c.getPackageManager();
        List<ApplicationInfo> a=new ArrayList<>();
        for(ApplicationInfo i:pm.getInstalledApplications(0))
            if(pm.getLaunchIntentForPackage(i.packageName)!=null && !i.packageName.equals(c.getPackageName())) a.add(i);
        Collections.sort(a,(x,y)->label(x).compareToIgnoreCase(label(y)));
        return a;
    }
    public String label(ApplicationInfo i){return c.getPackageManager().getApplicationLabel(i).toString();}
    public void launch(String pkg){
        Intent i=c.getPackageManager().getLaunchIntentForPackage(pkg);
        if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}
    }
    public ApplicationInfo find(String pkg) {
        for(ApplicationInfo i:all()) if(i.packageName.equals(pkg)) return i;
        return null;
    }
}
