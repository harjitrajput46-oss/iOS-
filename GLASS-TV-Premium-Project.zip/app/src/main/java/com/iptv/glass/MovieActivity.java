package com.iptv.glass;
import android.app.Activity;import android.os.Bundle;import android.graphics.Color;import android.widget.*;
public class MovieActivity extends Activity {
 private int d(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(d(30),d(22),d(30),d(22));root.setBackgroundColor(Color.rgb(7,11,22));
 Button back=new Button(this);back.setText("‹  HOME");back.setOnClickListener(v->finish());root.addView(back);
 TextView brand=new TextView(this);brand.setText("GLASS TV  /  CINEMA");brand.setTextColor(0xFF8CE7FF);brand.setTextSize(14);root.addView(brand);
 TextView title=new TextView(this);title.setText("MOVIE COLLECTION");title.setTextColor(Color.WHITE);title.setTextSize(30);title.setTypeface(null,1);root.addView(title);
 TextView sub=new TextView(this);sub.setText("A home for your entertainment services");sub.setTextColor(0xFFB8C9DA);sub.setTextSize(15);root.addView(sub);
 TextView note=new TextView(this);note.setText("No movie streams are bundled in this launcher. Use installed, authorized streaming apps from My Apps.");note.setTextColor(0xFFD4E4F0);note.setTextSize(16);note.setPadding(0,d(20),0,0);root.addView(note);setContentView(root);}
}
