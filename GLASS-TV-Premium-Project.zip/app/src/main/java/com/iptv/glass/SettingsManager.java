package com.iptv.glass;
import android.content.Context;
import android.content.SharedPreferences;

public class SettingsManager {
    private final SharedPreferences p;
    public SettingsManager(Context c) { p=c.getSharedPreferences("glass_tv_prefs", Context.MODE_PRIVATE); }
    public boolean favorite(String pkg) { return p.getBoolean("fav_"+pkg,false); }
    public void toggleFavorite(String pkg) { p.edit().putBoolean("fav_"+pkg,!favorite(pkg)).apply(); }
    public boolean enabled(String key) { return p.getBoolean("section_"+key,true); }
    public void setEnabled(String key, boolean value) { p.edit().putBoolean("section_"+key,value).apply(); }
    public void addRecent(String pkg) {
        String old=p.getString("recent","");
        java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();
        set.add(pkg);
        if(old.length()>0) for(String s:old.split("\\\\|")) if(!s.equals(pkg) && set.size()<12) set.add(s);
        StringBuilder b=new StringBuilder();
        for(String s:set){if(b.length()>0)b.append("|");b.append(s);}
        p.edit().putString("recent",b.toString()).apply();
    }
    public java.util.List<String> recent() {
        java.util.List<String> out=new java.util.ArrayList<>();
        String s=p.getString("recent","");
        if(s.length()>0) for(String x:s.split("\\\\|")) out.add(x);
        return out;
    }
}
