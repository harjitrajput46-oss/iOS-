package com.iptv.glass;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private AppManager apps;
    private SettingsManager prefs;
    private int white=Color.WHITE, muted=0xFFB8C9DA, cyan=0xFF8CE7FF;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        content=findViewById(R.id.content); apps=new AppManager(this); prefs=new SettingsManager(this);
        renderHome();
    }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private Button button(String s){
        Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(14);b.setAllCaps(false);
        b.setBackgroundResource(R.drawable.focus_card);b.setFocusable(true);b.setPadding(dp(14),dp(5),dp(14),dp(5));return b;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(int h){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void header(String subtitle){
        LinearLayout top=horizontal();
        TextView logo=label("GLASS",30,white,true);top.addView(logo);
        TextView tv=label(" TV",30,cyan,true);top.addView(tv);
        View spacer=new View(this);top.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        TextView clock=label(subtitle,13,muted,false);top.addView(clock);
        content.addView(top);
    }
    private void renderHome(){
        content.removeAllViews();header("HOME     •     ANDROID TV");
        gap(20);
        LinearLayout hero=vertical();hero.setPadding(dp(26),dp(20),dp(26),dp(20));hero.setBackgroundResource(R.drawable.glass_panel);
        TextView over=label("WELCOME TO YOUR ENTERTAINMENT SPACE",12,cyan,true);hero.addView(over);
        TextView title=label("A MORE CINEMATIC HOME.",30,white,true);hero.addView(title);
        TextView desc=label("Your apps. Your favorites. One beautiful screen.",16,muted,false);hero.addView(desc);
        LinearLayout actions=horizontal();
        Button explore=button("OPEN MY APPS  ›");explore.setOnClickListener(v->showApps(false));actions.addView(explore);
        Button anime=button("ANIME");anime.setOnClickListener(v->startActivity(new Intent(this,AnimeActivity.class)));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-2,dp(48));ap.leftMargin=dp(10);actions.addView(anime,ap);
        hero.addView(actions);content.addView(hero,new LinearLayout.LayoutParams(-1,-2));
        if(prefs.enabled("apps")){gap(18);appShelf("MY APPS",apps.all(),false);}
        if(prefs.enabled("anime")){gap(14);navCard("ANIME MINI APP","Movies  •  Series  •  Hindi Dub",()->startActivity(new Intent(this,AnimeActivity.class)));}
        if(prefs.enabled("movies")){gap(10);navCard("MOVIES","Your movie collection and authorized services",()->startActivity(new Intent(this,MovieActivity.class)));}
        if(prefs.enabled("favorites")){gap(14);List<ApplicationInfo> fav=new ArrayList<>();for(ApplicationInfo i:apps.all())if(prefs.favorite(i.packageName))fav.add(i);appShelf("FAVORITES",fav,true);}
        if(prefs.enabled("recent")){gap(14);List<ApplicationInfo> recent=new ArrayList<>();for(String p:prefs.recent()){ApplicationInfo i=apps.find(p);if(i!=null)recent.add(i);}appShelf("RECENTLY OPENED",recent,false);}
        gap(14);
        LinearLayout bottom=horizontal();
        Button settings=button("⚙  SETTINGS");settings.setOnClickListener(v->showSettings());bottom.addView(settings);
        TextView hint=label("   Navigate with your TV remote  •  OK to select",12,muted,false);bottom.addView(hint);
        content.addView(bottom);
    }
    private void navCard(String title,String sub,Runnable r){
        LinearLayout box=vertical();box.setPadding(dp(18),dp(13),dp(18),dp(13));box.setBackgroundResource(R.drawable.glass_panel);
        box.addView(label(title,20,white,true));box.addView(label(sub,13,muted,false));
        box.setFocusable(true);box.setOnClickListener(v->r.run());content.addView(box,new LinearLayout.LayoutParams(-1,dp(76)));
    }
    private void appShelf(String title,List<ApplicationInfo> list,boolean favoriteMode){
        content.addView(label(title,18,white,true));
        if(list.isEmpty()){content.addView(label(favoriteMode?"No favorites yet. Open My Apps and select ☆.":"No apps to show.",13,muted,false));return;}
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout rail=horizontal();
        for(ApplicationInfo info:list){
            LinearLayout card=vertical();card.setGravity(Gravity.CENTER);card.setPadding(dp(10),dp(9),dp(10),dp(9));card.setBackgroundResource(R.drawable.focus_card);card.setFocusable(true);
            ImageView icon=new ImageView(this);try{icon.setImageDrawable(getPackageManager().getApplicationIcon(info));}catch(Exception e){}
            card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            TextView name=label(apps.label(info),12,white,true);name.setGravity(Gravity.CENTER);name.setMaxLines(1);card.addView(name);
            card.setOnClickListener(v->{prefs.addRecent(info.packageName);apps.launch(info.packageName);});
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(116),dp(104));cp.rightMargin=dp(10);rail.addView(card,cp);
        }
        hsv.addView(rail);content.addView(hsv,new LinearLayout.LayoutParams(-1,dp(112)));
    }
    private void showApps(boolean favOnly){
        content.removeAllViews();header("LIBRARY     •     APPS");gap(16);
        Button back=button("‹  HOME");back.setOnClickListener(v->renderHome());content.addView(back);
        content.addView(label(favOnly?"FAVORITE APPS":"ALL INSTALLED APPS",22,white,true));gap(8);
        for(ApplicationInfo info:apps.all()){
            if(favOnly&&!prefs.favorite(info.packageName))continue;
            LinearLayout row=horizontal();row.setPadding(dp(10),dp(7),dp(10),dp(7));row.setBackgroundResource(R.drawable.focus_card);row.setFocusable(true);
            ImageView icon=new ImageView(this);try{icon.setImageDrawable(getPackageManager().getApplicationIcon(info));}catch(Exception e){}
            row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            TextView name=label(apps.label(info),16,white,true);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.leftMargin=dp(12);row.addView(name,np);
            Button star=button(prefs.favorite(info.packageName)?"★":"☆");star.setOnClickListener(v->{prefs.toggleFavorite(info.packageName);showApps(favOnly);});row.addView(star);
            row.setOnClickListener(v->{prefs.addRecent(info.packageName);apps.launch(info.packageName);});
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.bottomMargin=dp(7);content.addView(row,rp);
        }
    }
    private void showSettings(){
        content.removeAllViews();header("PERSONALIZE");gap(15);
        Button back=button("‹  HOME");back.setOnClickListener(v->renderHome());content.addView(back);
        content.addView(label("HOME SCREEN SECTIONS",22,white,true));
        addToggle("My Apps","apps");addToggle("Anime Mini App","anime");addToggle("Movies","movies");
        addToggle("Favorites","favorites");addToggle("Recently Opened","recent");
        gap(12);Button wallpaper=button("CHANGE WALLPAPER");
        wallpaper.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,42);});
        content.addView(wallpaper);
        content.addView(label("Choose an image from your device. The selection is applied as the home background.",12,muted,false));
    }
    private void addToggle(String title,String key){
        Switch s=new Switch(this);s.setText(title);s.setTextColor(white);s.setTextSize(16);s.setChecked(prefs.enabled(key));
        s.setOnCheckedChangeListener((b,v)->prefs.setEnabled(key,v));content.addView(s,new LinearLayout.LayoutParams(-1,dp(48)));
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==42&&res==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();getSharedPreferences("glass_tv_prefs",0).edit().putString("wallpaper",uri.toString()).apply();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            Toast.makeText(this,"Wallpaper saved. Reopen Home to apply.",Toast.LENGTH_SHORT).show();
        }
    }
    @Override protected void onResume(){super.onResume();if(content!=null&&content.getChildCount()>0){String wall=getSharedPreferences("glass_tv_prefs",0).getString("wallpaper",null);if(wall!=null&&content.getId()==R.id.content){try{content.setBackground(Drawable.createFromStream(getContentResolver().openInputStream(Uri.parse(wall)),null));}catch(Exception ignored){}}}}
}
