package com.iptv.glass;
import android.app.Activity;import android.os.Bundle;import android.graphics.Color;import android.view.Gravity;import android.widget.*;
public class AnimeActivity extends Activity {
 private int d(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(d(30),d(22),d(30),d(22));root.setBackgroundColor(Color.rgb(7,11,22));
 Button back=new Button(this);back.setText("‹  HOME");back.setOnClickListener(v->finish());root.addView(back);
 TextView brand=new TextView(this);brand.setText("GLASS TV  /  ANIME");brand.setTextColor(0xFF8CE7FF);brand.setTextSize(14);root.addView(brand);
 TextView title=new TextView(this);title.setText("ANIME UNIVERSE");title.setTextColor(Color.WHITE);title.setTextSize(30);title.setTypeface(null,1);root.addView(title);
 TextView sub=new TextView(this);sub.setText("Explore anime by collection");sub.setTextColor(0xFFB8C9DA);sub.setTextSize(15);root.addView(sub);
 for(String s:new String[]{"ANIME MOVIES","ANIME SERIES","HINDI DUB","FAVORITES","CONTINUE WATCHING"}){Button x=new Button(this);x.setText(s+"   ›");x.setTextColor(Color.WHITE);x.setAllCaps(false);x.setBackgroundResource(R.drawable.focus_card);root.addView(x,new LinearLayout.LayoutParams(-1,d(54)));}
 TextView note=new TextView(this);note.setText("Streaming catalogs are not bundled. Add only authorized provider links or legally available content.");note.setTextColor(0xFF9EB3C8);note.setTextSize(12);note.setPadding(0,d(16),0,0);root.addView(note);setContentView(root);}
}
